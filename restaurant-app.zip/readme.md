# This app created just for practice and testing

Learn Coding from Dicoding seems like a good way to grap some knowledge about proggramming and algorithm.
Course Material like is taft by mentor because material is designed by authors that have a good understanding and knowledge about arsitectur of app web, native apps, and more.
I know that this description is'nt related to this text.

```
(()=>{
document.writeln('just do it, forget the bugs and keep coding, improve later :) ')
})()
```
