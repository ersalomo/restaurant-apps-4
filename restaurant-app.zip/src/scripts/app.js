import { load } from './index.js';
import './dom-html.js';

window.addEventListener('DOMContentLoaded', load);
