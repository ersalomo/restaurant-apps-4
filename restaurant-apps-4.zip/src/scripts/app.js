import { load } from './index.js';

window.addEventListener('DOMContentLoaded', load);
